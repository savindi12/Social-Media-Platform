/* =========================================================
   CONNECT - MINI SOCIAL MEDIA PLATFORM
   Complete frontend application
========================================================= */


/* =========================================================
   STORAGE KEYS
========================================================= */

const STORAGE_KEYS = {
    user: "connect_user",
    tasks: "connect_tasks",
    notifications: "connect_notifications",
    posts: "connect_posts",
    people: "connect_people"
};


/* =========================================================
   DEFAULT PEOPLE
========================================================= */

const defaultPeople = [
    {
        id: 1,
        name: "Kasun Perera",
        role: "Software Developer",
        following: false
    },
    {
        id: 2,
        name: "Nimali Silva",
        role: "UI/UX Designer",
        following: false
    },
    {
        id: 3,
        name: "Tharindu Fernando",
        role: "Project Manager",
        following: false
    },
    {
        id: 4,
        name: "Amaya Jayasinghe",
        role: "Full Stack Developer",
        following: false
    },
    {
        id: 5,
        name: "Ravindu Senanayake",
        role: "Product Designer",
        following: false
    },
    {
        id: 6,
        name: "Dinuka Peris",
        role: "Web Developer",
        following: false
    }
];


/* =========================================================
   DEFAULT POSTS
========================================================= */

const defaultPosts = [
    {
        id: 1,
        author: "Kasun Perera",
        text: "Welcome to Connect! 🚀",
        likes: 4,
        liked: false,
        createdAt: Date.now() - 3600000
    },

    {
        id: 2,
        author: "Nimali Silva",
        text: "Working on a new UI design today. 🎨",
        likes: 7,
        liked: false,
        createdAt: Date.now() - 7200000
    },

    {
        id: 3,
        author: "Tharindu Fernando",
        text: "Great progress on our project!",
        likes: 3,
        liked: false,
        createdAt: Date.now() - 10800000
    }
];


/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function getStorage(key, fallback) {

    try {

        const value = localStorage.getItem(key);

        if (!value) {
            return fallback;
        }

        return JSON.parse(value);

    } catch (error) {

        console.error(
            "Storage error:",
            error
        );

        return fallback;
    }
}


function setStorage(key, value) {

    try {

        localStorage.setItem(
            key,
            JSON.stringify(value)
        );

    } catch (error) {

        console.error(
            "Could not save data:",
            error
        );
    }
}


function escapeHTML(value) {

    if (value === null || value === undefined) {
        return "";
    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


function generateId() {

    return Date.now() +
        Math.floor(
            Math.random() * 100000
        );
}


function getInitials(name) {

    return name
        .split(" ")
        .map(word => word.charAt(0))
        .slice(0, 2)
        .join("")
        .toUpperCase();
}


function formatTime(timestamp) {

    const date = new Date(timestamp);

    const now = new Date();

    const difference =
        now.getTime() - date.getTime();

    const seconds =
        Math.floor(difference / 1000);

    if (seconds < 60) {
        return "Just now";
    }

    const minutes =
        Math.floor(seconds / 60);

    if (minutes < 60) {
        return `${minutes} min ago`;
    }

    const hours =
        Math.floor(minutes / 60);

    if (hours < 24) {
        return `${hours} hour${hours > 1 ? "s" : ""} ago`;
    }

    const days =
        Math.floor(hours / 24);

    if (days < 7) {
        return `${days} day${days > 1 ? "s" : ""} ago`;
    }

    return date.toLocaleDateString();
}


/* =========================================================
   APPLICATION STATE
========================================================= */

let currentUser =
    getStorage(
        STORAGE_KEYS.user,
        null
    );

let tasks =
    getStorage(
        STORAGE_KEYS.tasks,
        []
    );

let notifications =
    getStorage(
        STORAGE_KEYS.notifications,
        []
    );

let posts =
    getStorage(
        STORAGE_KEYS.posts,
        defaultPosts
    );

let people =
    getStorage(
        STORAGE_KEYS.people,
        defaultPeople
    );


/* =========================================================
   DOM ELEMENTS
========================================================= */

const feedSection =
    document.getElementById(
        "feedSection"
    );

const peopleSection =
    document.getElementById(
        "peopleSection"
    );

const tasksSection =
    document.getElementById(
        "tasksSection"
    );

const loginButton =
    document.getElementById(
        "loginButton"
    );

const loginMessage =
    document.getElementById(
        "loginMessage"
    );

const feedList =
    document.getElementById(
        "feedList"
    );

const peopleList =
    document.getElementById(
        "peopleList"
    );

const taskList =
    document.getElementById(
        "taskList"
    );

const createTaskButton =
    document.getElementById(
        "createTaskButton"
    );

const taskFormContainer =
    document.getElementById(
        "taskFormContainer"
    );

const taskTitle =
    document.getElementById(
        "taskTitle"
    );

const taskDescription =
    document.getElementById(
        "taskDescription"
    );

const taskDate =
    document.getElementById(
        "taskDate"
    );

const taskPriority =
    document.getElementById(
        "taskPriority"
    );

const saveTaskButton =
    document.getElementById(
        "saveTaskButton"
    );

const cancelTaskButton =
    document.getElementById(
        "cancelTaskButton"
    );

const notificationButton =
    document.getElementById(
        "notificationButton"
    );

const notificationPanel =
    document.getElementById(
        "notificationPanel"
    );

const notificationList =
    document.getElementById(
        "notificationList"
    );

const notificationCount =
    document.getElementById(
        "notificationCount"
    );

const closeNotificationButton =
    document.getElementById(
        "closeNotificationButton"
    );

const markNotificationsRead =
    document.getElementById(
        "markNotificationsRead"
    );

const loginModal =
    document.getElementById(
        "loginModal"
    );

const usernameInput =
    document.getElementById(
        "usernameInput"
    );

const submitLoginButton =
    document.getElementById(
        "submitLoginButton"
    );

const closeLoginModal =
    document.getElementById(
        "closeLoginModal"
    );

const createPostButton =
    document.getElementById(
        "createPostButton"
    );

const postFormContainer =
    document.getElementById(
        "postFormContainer"
    );

const postText =
    document.getElementById(
        "postText"
    );

const cancelPostButton =
    document.getElementById(
        "cancelPostButton"
    );

const submitPostButton =
    document.getElementById(
        "submitPostButton"
    );

const taskDetailsModal =
    document.getElementById(
        "taskDetailsModal"
    );

const taskDetailsContent =
    document.getElementById(
        "taskDetailsContent"
    );

const closeTaskDetails =
    document.getElementById(
        "closeTaskDetails"
    );


/* =========================================================
   NAVIGATION
========================================================= */

document
    .querySelectorAll(".nav-btn[data-section]")
    .forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const sectionId =
                    button.dataset.section;

                showSection(sectionId);

            }
        );

    });


function showSection(sectionId) {

    document
        .querySelectorAll(".page-section")
        .forEach(section => {

            section.classList.remove(
                "active-section"
            );

        });


    const selectedSection =
        document.getElementById(
            sectionId
        );

    if (selectedSection) {

        selectedSection.classList.add(
            "active-section"
        );
    }


    document
        .querySelectorAll(
            ".nav-btn[data-section]"
        )
        .forEach(button => {

            button.classList.toggle(
                "active",
                button.dataset.section === sectionId
            );

        });


    if (sectionId === "tasksSection") {
        renderTasks();
    }

    if (sectionId === "peopleSection") {
        renderPeople();
    }

    if (sectionId === "feedSection") {
        renderFeed();
    }
}


/* =========================================================
   LOGIN
========================================================= */

loginButton.addEventListener(
    "click",
    () => {

        if (currentUser) {

            const shouldLogout =
                confirm(
                    `Logout ${currentUser.name}?`
                );

            if (!shouldLogout) {
                return;
            }

            currentUser = null;

            localStorage.removeItem(
                STORAGE_KEYS.user
            );

            updateLoginUI();

            addNotification(
                "You have been logged out."
            );

            return;
        }

        loginModal.classList.remove(
            "hidden"
        );

        setTimeout(() => {
            usernameInput.focus();
        }, 100);

    }
);


closeLoginModal.addEventListener(
    "click",
    () => {

        loginModal.classList.add(
            "hidden"
        );

    }
);


submitLoginButton.addEventListener(
    "click",
    loginUser
);


usernameInput.addEventListener(
    "keydown",
    event => {

        if (event.key === "Enter") {
            loginUser();
        }

    }
);


function loginUser() {

    const name =
        usernameInput.value.trim();

    if (!name) {

        alert(
            "Please enter your name."
        );

        usernameInput.focus();

        return;
    }


    currentUser = {
        id: generateId(),
        name: name
    };


    setStorage(
        STORAGE_KEYS.user,
        currentUser
    );


    loginModal.classList.add(
        "hidden"
    );


    usernameInput.value = "";


    updateLoginUI();


    addNotification(
        `Welcome to Connect, ${name}!`
    );


    renderFeed();

    renderTasks();

    renderPeople();
}


function updateLoginUI() {

    if (currentUser) {

        loginButton.textContent =
            "Logout";

        loginMessage.textContent =
            `Welcome back, ${currentUser.name}! Your personalized feed is ready.`;

        loginMessage.classList.remove(
            "hidden"
        );

    } else {

        loginButton.textContent =
            "Login";

        loginMessage.textContent =
            "Login to see your personalized feed.";

    }

}


/* =========================================================
   TASK FORM
========================================================= */

createTaskButton.addEventListener(
    "click",
    () => {

        taskFormContainer.classList.toggle(
            "hidden"
        );

        if (
            !taskFormContainer.classList.contains(
                "hidden"
            )
        ) {

            taskTitle.focus();

        }

    }
);


cancelTaskButton.addEventListener(
    "click",
    closeTaskForm
);


function closeTaskForm() {

    taskFormContainer.classList.add(
        "hidden"
    );

    taskTitle.value = "";
    taskDescription.value = "";
    taskDate.value = "";
    taskPriority.value = "medium";

}


/* =========================================================
   CREATE TASK
========================================================= */

saveTaskButton.addEventListener(
    "click",
    createTask
);


function createTask() {

    const title =
        taskTitle.value.trim();

    const description =
        taskDescription.value.trim();

    const dueDate =
        taskDate.value;

    const priority =
        taskPriority.value;


    if (!title) {

        alert(
            "Please enter a task title."
        );

        taskTitle.focus();

        return;
    }


    const newTask = {

        id: generateId(),

        title: title,

        description:
            description ||
            "No description provided.",

        dueDate:
            dueDate || null,

        priority: priority,

        completed: false,

        createdAt: Date.now(),

        createdBy:
            currentUser
                ? currentUser.name
                : "Guest"

    };


    tasks.unshift(
        newTask
    );


    setStorage(
        STORAGE_KEYS.tasks,
        tasks
    );


    closeTaskForm();


    renderTasks();


    addNotification(
        `New task created: "${title}"`
    );


    alert(
        "Task created successfully!"
    );

}


/* =========================================================
   RENDER TASKS
========================================================= */

function renderTasks() {

    if (!taskList) {
        return;
    }


    if (tasks.length === 0) {

        taskList.innerHTML = `
            <div class="empty-state">
                <h3>No tasks yet</h3>
                <p>
                    Click "Create Task" to add your first task.
                </p>
            </div>
        `;

        return;
    }


    taskList.innerHTML =
        tasks.map(task => {

            const dueDateText =
                task.dueDate
                    ? new Date(
                        task.dueDate + "T00:00:00"
                    ).toLocaleDateString()
                    : "No due date";


            return `

                <article
                    class="task-card ${task.completed ? "completed" : ""}"
                >

                    <div class="task-main">

                        <div class="task-title-row">

                            <input
                                type="checkbox"
                                class="task-checkbox"
                                data-task-id="${task.id}"
                                ${task.completed ? "checked" : ""}
                            >

                            <h3 class="task-title">
                                ${escapeHTML(task.title)}
                            </h3>

                        </div>


                        <p class="task-description">
                            ${escapeHTML(task.description)}
                        </p>


                        <div class="task-meta">

                            <span
                                class="task-badge priority-${task.priority}"
                            >
                                ${escapeHTML(task.priority)}
                            </span>

                            <span class="task-badge status-badge">
                                ${
                                    task.completed
                                        ? "Completed"
                                        : "Pending"
                                }
                            </span>

                            <span class="task-badge status-badge">
                                Due: ${escapeHTML(dueDateText)}
                            </span>

                        </div>

                    </div>


                    <div class="task-actions">

                        <button
                            class="secondary-btn view-task-btn"
                            data-task-id="${task.id}"
                            type="button"
                        >
                            View
                        </button>

                        <button
                            class="danger-btn delete-task-btn"
                            data-task-id="${task.id}"
                            type="button"
                        >
                            Delete
                        </button>

                    </div>

                </article>

            `;

        }).join("");


    document
        .querySelectorAll(".task-checkbox")
        .forEach(checkbox => {

            checkbox.addEventListener(
                "change",
                () => {

                    toggleTask(
                        Number(
                            checkbox.dataset.taskId
                        )
                    );

                }
            );

        });


    document
        .querySelectorAll(".delete-task-btn")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    deleteTask(
                        Number(
                            button.dataset.taskId
                        )
                    );

                }
            );

        });


    document
        .querySelectorAll(".view-task-btn")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    viewTask(
                        Number(
                            button.dataset.taskId
                        )
                    );

                }
            );

        });

}


/* =========================================================
   TOGGLE TASK
========================================================= */

function toggleTask(taskId) {

    const task =
        tasks.find(
            item => item.id === taskId
        );

    if (!task) {
        return;
    }


    task.completed =
        !task.completed;


    setStorage(
        STORAGE_KEYS.tasks,
        tasks
    );


    renderTasks();


    if (task.completed) {

        addNotification(
            `Task completed: "${task.title}"`
        );

    } else {

        addNotification(
            `Task reopened: "${task.title}"`
        );

    }

}


/* =========================================================
   DELETE TASK
========================================================= */

function deleteTask(taskId) {

    const task =
        tasks.find(
            item => item.id === taskId
        );

    if (!task) {
        return;
    }


    const confirmed =
        confirm(
            `Delete "${task.title}"?`
        );


    if (!confirmed) {
        return;
    }


    tasks =
        tasks.filter(
            item => item.id !== taskId
        );


    setStorage(
        STORAGE_KEYS.tasks,
        tasks
    );


    renderTasks();


    addNotification(
        `Task deleted: "${task.title}"`
    );

}


/* =========================================================
   VIEW TASK
========================================================= */

function viewTask(taskId) {

    const task =
        tasks.find(
            item => item.id === taskId
        );

    if (!task) {
        return;
    }


    const dueDate =
        task.dueDate
            ? new Date(
                task.dueDate + "T00:00:00"
            ).toLocaleDateString()
            : "No due date";


    taskDetailsContent.innerHTML = `

        <h2 class="detail-title">
            ${escapeHTML(task.title)}
        </h2>

        <p class="detail-description">
            ${escapeHTML(task.description)}
        </p>


        <div class="detail-row">

            <span class="detail-label">
                Status
            </span>

            <span class="detail-value">
                ${
                    task.completed
                        ? "Completed"
                        : "Pending"
                }
            </span>

        </div>


        <div class="detail-row">

            <span class="detail-label">
                Priority
            </span>

            <span class="detail-value">
                ${escapeHTML(task.priority)}
            </span>

        </div>


        <div class="detail-row">

            <span class="detail-label">
                Due date
            </span>

            <span class="detail-value">
                ${escapeHTML(dueDate)}
            </span>

        </div>


        <div class="detail-row">

            <span class="detail-label">
                Created by
            </span>

            <span class="detail-value">
                ${escapeHTML(task.createdBy)}
            </span>

        </div>

    `;


    taskDetailsModal.classList.remove(
        "hidden"
    );

}


closeTaskDetails.addEventListener(
    "click",
    () => {

        taskDetailsModal.classList.add(
            "hidden"
        );

    }
);


/* =========================================================
   NOTIFICATIONS
========================================================= */

notificationButton.addEventListener(
    "click",
    event => {

        event.stopPropagation();

        notificationPanel.classList.toggle(
            "hidden"
        );

        renderNotifications();

    }
);


closeNotificationButton.addEventListener(
    "click",
    () => {

        notificationPanel.classList.add(
            "hidden"
        );

    }
);


document.addEventListener(
    "click",
    event => {

        if (
            !notificationPanel.contains(
                event.target
            ) &&
            !notificationButton.contains(
                event.target
            )
        ) {

            notificationPanel.classList.add(
                "hidden"
            );

        }

    }
);


function addNotification(message) {

    const notification = {

        id: generateId(),

        message: message,

        read: false,

        createdAt: Date.now()

    };


    notifications.unshift(
        notification
    );


    if (notifications.length > 50) {

        notifications =
            notifications.slice(0, 50);

    }


    setStorage(
        STORAGE_KEYS.notifications,
        notifications
    );


    renderNotifications();

    updateNotificationCount();

}


function renderNotifications() {

    if (!notificationList) {
        return;
    }


    if (notifications.length === 0) {

        notificationList.innerHTML = `
            <div class="empty-state">
                No notifications yet.
            </div>
        `;

        return;
    }


    notificationList.innerHTML =
        notifications.map(notification => {

            return `

                <div
                    class="
                        notification-item
                        ${notification.read ? "" : "unread"}
                    "
                >

                    <div class="notification-icon">
                        🔔
                    </div>

                    <div class="notification-text">

                        ${escapeHTML(
                            notification.message
                        )}

                        <span class="notification-time">
                            ${formatTime(
                                notification.createdAt
                            )}
                        </span>

                    </div>

                </div>

            `;

        }).join("");

}


markNotificationsRead.addEventListener(
    "click",
    () => {

        notifications =
            notifications.map(
                notification => ({
                    ...notification,
                    read: true
                })
            );


        setStorage(
            STORAGE_KEYS.notifications,
            notifications
        );


        renderNotifications();

        updateNotificationCount();

    }
);


function updateNotificationCount() {

    const unreadCount =
        notifications.filter(
            notification =>
                !notification.read
        ).length;


    if (unreadCount > 0) {

        notificationCount.textContent =
            unreadCount > 99
                ? "99+"
                : unreadCount;

        notificationCount.classList.remove(
            "hidden"
        );

    } else {

        notificationCount.classList.add(
            "hidden"
        );

    }

}


/* =========================================================
   PEOPLE
========================================================= */

function renderPeople() {

    if (!peopleList) {
        return;
    }


    peopleList.innerHTML =
        people.map(person => {

            return `

                <article class="person-card">

                    <div class="avatar">
                        ${getInitials(person.name)}
                    </div>

                    <h3 class="person-name">
                        ${escapeHTML(person.name)}
                    </h3>

                    <p class="person-role">
                        ${escapeHTML(person.role)}
                    </p>

                    <button
                        class="
                            ${
                                person.following
                                    ? "secondary-btn"
                                    : "primary-btn"
                            }
                        "
                        data-person-id="${person.id}"
                        onclick="toggleFollow(${person.id})"
                    >
                        ${
                            person.following
                                ? "Following"
                                : "Follow"
                        }
                    </button>

                </article>

            `;

        }).join("");

}


function toggleFollow(personId) {

    const person =
        people.find(
            item => item.id === personId
        );

    if (!person) {
        return;
    }


    person.following =
        !person.following;


    setStorage(
        STORAGE_KEYS.people,
        people
    );


    renderPeople();


    if (person.following) {

        addNotification(
            `You are now following ${person.name}.`
        );

    } else {

        addNotification(
            `You unfollowed ${person.name}.`
        );

    }

}


/* =========================================================
   POSTS
========================================================= */

createPostButton.addEventListener(
    "click",
    () => {

        if (!currentUser) {

            loginModal.classList.remove(
                "hidden"
            );

            usernameInput.focus();

            return;
        }


        postFormContainer.classList.toggle(
            "hidden"
        );


        if (
            !postFormContainer.classList.contains(
                "hidden"
            )
        ) {

            postText.focus();

        }

    }
);


cancelPostButton.addEventListener(
    "click",
    () => {

        postFormContainer.classList.add(
            "hidden"
        );

        postText.value = "";

    }
);


submitPostButton.addEventListener(
    "click",
    createPost
);


function createPost() {

    if (!currentUser) {

        alert(
            "Please login first."
        );

        return;
    }


    const text =
        postText.value.trim();


    if (!text) {

        alert(
            "Please write something."
        );

        postText.focus();

        return;
    }


    const newPost = {

        id: generateId(),

        author:
            currentUser.name,

        text: text,

        likes: 0,

        liked: false,

        createdAt: Date.now()

    };


    posts.unshift(
        newPost
    );


    setStorage(
        STORAGE_KEYS.posts,
        posts
    );


    postText.value = "";

    postFormContainer.classList.add(
        "hidden"
    );


    renderFeed();


    addNotification(
        "Your post was published."
    );

}


function renderFeed() {

    if (!feedList) {
        return;
    }


    if (posts.length === 0) {

        feedList.innerHTML = `
            <div class="empty-state">
                No posts available.
            </div>
        `;

        return;
    }


    feedList.innerHTML =
        posts.map(post => {

            return `

                <article class="post-card">

                    <div class="post-header">

                        <div class="avatar">
                            ${getInitials(
                                post.author
                            )}
                        </div>

                        <div>

                            <div class="post-author">
                                ${escapeHTML(
                                    post.author
                                )}
                            </div>

                            <div class="post-time">
                                ${formatTime(
                                    post.createdAt
                                )}
                            </div>

                        </div>

                    </div>


                    <div class="post-text">
                        ${escapeHTML(
                            post.text
                        )}
                    </div>


                    <div class="post-actions">

                        <button
                            class="
                                action-btn
                                ${post.liked ? "liked" : ""}
                            "
                            onclick="toggleLike(${post.id})"
                        >
                            ❤️ ${post.likes}
                        </button>

                        <button
                            class="action-btn"
                            onclick="showCommentMessage()"
                        >
                            💬 Comment
                        </button>

                        <button
                            class="action-btn"
                            onclick="sharePost(${post.id})"
                        >
                            ↗ Share
                        </button>

                    </div>

                </article>

            `;

        }).join("");

}


function toggleLike(postId) {

    const post =
        posts.find(
            item => item.id === postId
        );

    if (!post) {
        return;
    }


    post.liked =
        !post.liked;


    if (post.liked) {

        post.likes++;

    } else {

        post.likes =
            Math.max(
                0,
                post.likes - 1
            );

    }


    setStorage(
        STORAGE_KEYS.posts,
        posts
    );


    renderFeed();

}


function showCommentMessage() {

    alert(
        "Comment feature is ready to connect to your backend."
    );

}


function sharePost(postId) {

    const post =
        posts.find(
            item => item.id === postId
        );

    if (!post) {
        return;
    }


    if (
        navigator.clipboard &&
        navigator.clipboard.writeText
    ) {

        navigator.clipboard
            .writeText(post.text)
            .then(() => {

                addNotification(
                    "Post text copied to clipboard."
                );

                alert(
                    "Post copied to clipboard."
                );

            })
            .catch(() => {

                alert(
                    "Could not copy the post."
                );

            });

    } else {

        alert(
            "Share feature is not available in this browser."
        );

    }

}


/* =========================================================
   MODAL OUTSIDE CLICK
========================================================= */

loginModal.addEventListener(
    "click",
    event => {

        if (
            event.target === loginModal
        ) {

            loginModal.classList.add(
                "hidden"
            );

        }

    }
);


taskDetailsModal.addEventListener(
    "click",
    event => {

        if (
            event.target === taskDetailsModal
        ) {

            taskDetailsModal.classList.add(
                "hidden"
            );

        }

    }
);


/* =========================================================
   INITIALIZE APPLICATION
========================================================= */

function initializeApp() {

    updateLoginUI();

    renderFeed();

    renderPeople();

    renderTasks();

    renderNotifications();

    updateNotificationCount();

}


/* Start application */

initializeApp();