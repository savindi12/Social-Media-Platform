# Task 2 – Social Media Platform

Implements user profiles, posts, comments, likes/follows, authentication and MySQL persistence.

Run `database.sql`, then `npm install`, configure `.env`, and `npm start`. Open http://localhost:3002.
